<?php

class Abonnement {

    public static function insert($pdo, $dateAbonnement, $duree, $idLecteur) {
        try {
            $sql = "INSERT INTO 5minutes.abonnement (dateAbonnement, duree, idLecteur) values(?,?,?)";
            $cursor = $pdo->prepare($sql);
            $cursor->execute(array($dateAbonnement, $duree, $idLecteur));
            return(1);
        } catch (PDOException $e) {
            return($e);
        }
    }

    public static function selectAll($pdo) {
        try {
            $sql = "SELECT * FROM 5minutes.abonnement";
            $cursor = $pdo()->query($sql);
            $cursor->setFetchMode(PDO::FETCH_ASSOC);
            $ret = $cursor->fetchAll();
            if ($ret == false) {
                return null;
            } else {
                return $ret;
            }
        } catch (PDOException $e) {
            return($e);
        }
    }

    public static function update($pdo, $idAbonnement, $dateAbonnement, $duree, $idLecteur) {
        try {
            $sql = "UPDATE 5minutes.abonnement SET dateAbonnement = ?, duree = ?, idLecteur = ? WHERE idAbonnement = ?";
            $cursor = $pdo->prepare($sql);
            $cursor->execute(array($dateAbonnement, $duree, $idLecteur, $idAbonnement));
            return(1);
        } catch (PDOException $e) {
            return($e);
        }
    }

    public static function delete($pdo, $idAbonnement, $dateAbonnement, $duree, $idLecteur) {
        try {
            $sql = "DELETE FROM 5minutes.abonnement WHERE idAbonnement = ?";
            $cursor = $pdo->prepare($sql);
            $cursor->execute(array($idAbonnement, $dateAbonnement, $duree, $idLecteur));
            return(1);
        } catch (PDOException $e) {
            return($e);
        }
    }

    public static function selectOne($pdo, $idAbonnement) {
        try {
            $sql = "DELETE FROM 5minutes.abonnement WHERE idAbonnement = ?";
            $cursor = $pdo->prepare($sql);
            $cursor->execute(array($idAbonnement));
            $cursor->setFetchMode(PDO::FETCH_ASSOC);
            $ret = $cursor->fetch();
            if ($ret == false) {
                return null;
            } else {
                return $ret;
            }
        } catch (PDOException $e) {
            return($e);
        }
    }

}

?>